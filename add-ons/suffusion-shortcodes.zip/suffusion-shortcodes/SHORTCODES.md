# Shortcodes to Enhance Functionality

Suffusion comes armed with a good set of very useful shortcodes. You can use these in your posts or widgets to display dynamic content as required.

## What is a Shortcode?

A shortcode is a macro code introduced in WordPress 2.5. When inserted into regular content, the shortcode executes a piece of associated PHP code that prints out specific output. The most common example of shortcodes is the “gallery” shortcode provided by WordPress out of the box.

## Suffusion Shortcodes

The following is the list of shortcodes provided within Suffusion:

1. Shortcode: `[suffusion-categories]`

   *Brief Description:* Used to print a list of categories.

   *Parameters and Usage:* This takes most if not all parameters of the WP call for `wp_list_categories()`.

   *Use Case:* If you want to display the list of categories from within a post. Since you can use most options of `wp_list_categories`, this is as powerful as running a query in the back-end.

1. Shortcode: `[suffusion-the-year]`

   *Brief Description:* Prints the current year.

   *Parameters and Usage:* This doesn’t take any parameters. Simply invoking `[suffusion-the-year]` prints the current year. 
   
   *Use Case:* If you want the current year to be shown in the copyright.

1. Shortcode: `[suffusion-site-link]`

   *Brief Description:* Prints the link to your site.

   *Parameters and Usage:* This doesn’t take any parameters. Simply invoking `[suffusion-site-link]` prints the title of your site and links it to your site.

   *Use Case:* If you want to print the title of your site with a URL linking to it.

1. Shortcode: `[suffusion-the-author]`
   
   *Brief Description:* Used to print information about the author of a post.

   *Parameters and Usage:* This takes one parameter, display. Depending on the value of display certain information is printed about the author of a post. The display parameter could have any of the following values:

   - `author` – Displays the display name of the author of the post
   - `modified-author` – Displays the display name of the author who modified the post
   - `description` – Displays the biographical information set in the author’s profile
   - `login` – Displays the login name of the author of the post
   - `first-name` – Displays the first name of the author of the post
   - `last-name` – Displays the last name of the author of the post
   - `nickname` – Displays the nickname of the author of the post
   - `id` – Displays the id of the author of the post
   - `url` – Displays the URL of the author of the post. This is only the URL, hence it needs to be suitably combined with the name of the author for a meaningful display
   - `email` – Displays the email of the author of the post
   - `link` – Displays the name of the author of the post, linking to the author’s URL
   - `aim` – Displays the AIM details of the author of the post. For this to work the AIM account details should be set in the user profile section of the author.
   - `yim` – Displays the Yahoo details of the author of the post. For this to work the Yahoo account details should be set in the user profile section of the author.
   - `posts` – Displays the number of posts written by the author of the post.
   - `posts-url` – Displays the URL for all posts by the author. Since this is only a URL, it might need to be combined with some more meaningful text for a better display.
   - `twitter` – Displays the link to the Twitter URL of the author of the post. Requires you to set up Twitter as a user contact method from Blog Features → User Profiles
   - `facebook` – Displays the link to the Facebook URL of the author of the post. Requires you to set up Facebook as a user contact method from Blog Features → User Profiles
   - `technorati` – Displays the link to the Technorati URL of the author of the post. Requires you to set up Technorati as a user contact method from Blog Features → User Profiles
   - `linkedin` – Displays the link to the LinkedIn URL of the author of the post. Requires you to set up LinkedIn as a user contact method from Blog Features → User Profiles
   - `flickr` – Displays the link to the Flickr URL of the author of the post. Requires you to set up Flickr as a user contact method from Blog Features → User Profiles
   - `delicious` – Displays the link to the Del.icio.us URL of the author of the post. Requires you to set up Del.icio.us as a user contact method from Blog Features → User Profiles
   - `digg` – Displays the link to the Digg URL of the author of the post. Requires you to set up Digg as a user contact method from Blog Features → User Profiles
   - `stumbleupon` – Displays the link to the StumbleUpon URL of the author of the post. Requires you to set up StumbleUpon as a user contact method from Blog Features → User Profiles
   - `reddit` – Displays the link to the Reddit URL of the author of the post. Requires you to set up Reddit as a user contact method from Blog Features → User Profiles

   *Use Case:* If you want to insert author-specific information at the bottom of a post, like the number of articles, a brief description etc.

   *Example:*

   ```
   [suffusion-the-author display='author']` has written <a href='[suffusion-the-author display='posts-url']'> [suffusion-the-author display='posts'] posts</a>. He can be followed on <a href='[suffusion-the-author display='twitter']'>Twitter</a>.
   ```

1. Shortcode: `[suffusion-the-post]`
   
   *Brief Description:* Used to print information about a post, like the ID, title and permalink.

   *Parameters and Usage:* This takes one parameter, display. Depending on the value of display a certain piece of information is displayed. 

   *Use Case:* If you want to insert post-specific information at the bottom of a post.

   *Example:*

   ```
   This post has an id [suffusion-the-post display='id']. Its permalink is [suffusion-the-post display='permalink'] and the title is [suffusion-the-post display='title'].
   ```

1. Shortcode: `[suffusion-login-url]`
   
   *Brief Description:* Prints the login URL for the site.

   *Parameters and Usage:* This takes no parameters.

   *Use Case:* If you don’t want the Meta widget, but want to show a login URL

1. Shortcode: `[suffusion-logout-url]`
   
   *Brief Description:* Prints the logout URL for the site.

   *Parameters and Usage:* This takes no parameters.

   *Use Case:* If you don’t want the Meta widget, but want to show a logout URL

1. Shortcode: `[suffusion-loginout]`
   
   *Brief Description:* Prints the URL to log in if logged out or logout if logged in.

   *Parameters and Usage:* This takes no parameters.

   *Use Case:* If you don’t want the Meta widget, but want to show a URL to logout if a user is logged in and vice versa.

1. Shortcode: `[suffusion-register]`
   
   *Brief Description:* Prints the URL to register as a member of the site.

   *Parameters and Usage:* This takes no parameters.

   *Use Case:* If you don’t want the Meta widget, but want to show a registration URL

1. Shortcode: `[suffusion-adsense]`
   
   *Brief Description:* Prints AdSense code based on specified parameters.

   *Parameters and Usage:* This takes four parameters: client, slot, width and height. It inserts the corresponding ad when invoked. I don’t have an AdSense account, so I cannot demonstrate this, though.

   *Use Case:* If you want to insert an advertisement in the body of a post.

1. Shortcode: `[suffusion-tag-cloud]`
   
   *Brief Description:* Prints a tag cloud.

   *Parameters and Usage:* This takes three parameters: smallest, largest and number, respectively indicating the smallest font size (default 8), the largest font size (default 22) and the number of tags to display (default 45).

   *Use Case:* If you are not satisfied with the default “Tag Cloud” widget and would like more control over how many tags to display and in what sizes. You could use this in a text widget too, to simulate the tag-cloud widget.

1. Shortcode: `[suffusion-widgets]`
   
   *Brief Description:* Prints an ad hoc widget area, based on specified parameters.

   *Parameters and Usage:* To use this shortcode you first have to go to Appearance → Widgets, then fill in the widgets you want in the widget areas titled Ad Hoc Widgets 1, Ad Hoc Widgets 2, … Ad Hoc Widgets 5. You don’t need to put widgets in all of them – just put them in the ones you want to use. The shortcode takes 3 parameters – `id`, `container` and `container_class`. 
   
   *Example:*

   ```
   [suffusion-widgets id='2' container_class='custom-class']
   ```

   This prints the widget area for Ad Hoc Widgets 2 and assigns the widget area a class called ‘custom-class’. If you pass the container parameter with a value 'false' then the widgets are not put in any container (and the container_class parameter is ignored).

   *Use Case:* If you want to display some widgets from within a post.

1. Shortcode: `[audio]`
   
   *Brief Description:* Lets you embed an audio player linking to a file.

   *Parameters and Usage:* To use this shortcode just pass the URL of the MP3 file that you want to embed. 
   
   *Example:*

   `[audio http://wpcom.files.wordpress.com/2007/01/mattmullenweg-interview.mp3]`

1. Shortcode: `[suffusion-multic]` and `[suffusion-column]`
   
   *Brief Description:* This was introduced in version 3.6.0 to support multi-column layouts. These shortcodes are dependent on each other.

   *Parameters and Usage:* The `[suffusion-multic]` shortcode takes no parameters and is used as a container indicating that you have a multi-column layout within. The `[suffusion-column]` shortcode takes the parameter width, which could have values 1, 1/2, 1/3, 1/4, 2/3, 3/4, 100, 050, 033, 025, 066 and 075, indicating what fraction of the width is to be taken up by a column. The default is 1. This is how you can use the shortcode:

   ```
   [suffusion-multic]
      [suffusion-column width='1/2']A column with 1/2 the total width [/suffusion-column]
      [suffusion-column width='1/4']A column with 1/4 the total width[/suffusion-column]
      [suffusion-column width='1/4']Another column with 1/4 the total width[/suffusion-column]
   [/suffusion-multic]
   ```

   Mind you, WP has a nasty habit of inserting `<p>` tags at line breaks, so you might have to be careful about stripping out new lines from the above code before using it.